// Vertex GL version
#version 330 compatibility

#define GBUFFERS
#define SPIDER_EYES
#define VERTEX

#include "/lib/settings.glsl"
#include "/lib/utility/common.glsl"

#include "world.glsl"
#include "/main/gbuffers/gbuffers_spidereyes.glsl"