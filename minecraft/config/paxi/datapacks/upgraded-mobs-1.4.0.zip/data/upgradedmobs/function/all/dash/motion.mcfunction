execute summon marker facing entity @p[gamemode=!creative,gamemode=!spectator] feet positioned 0.0 0.0 0.0 run function upgradedmobs:all/dash/marker

data modify entity @s Motion set from storage upgradedmobs:dash/storage Motion
data modify entity @s FallDistance set value -12
