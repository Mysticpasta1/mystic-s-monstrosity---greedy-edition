execute if predicate math:chance/10 run enchant @s quick_charge 2

execute if predicate math:chance/10 run item replace entity @s weapon.offhand with minecraft:tipped_arrow[potion_contents="minecraft:weakness"] 64

execute if predicate math:chance/2 run item replace entity @s weapon.offhand with minecraft:firework_rocket[fireworks={flight_duration:3b, explosions:[{shape: burst, colors:[11743532], has_trail:true}]}]
