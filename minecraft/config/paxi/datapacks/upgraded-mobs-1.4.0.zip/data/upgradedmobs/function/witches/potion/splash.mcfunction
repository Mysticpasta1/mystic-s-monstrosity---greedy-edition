execute if predicate math:chance/25 run data merge entity @s {Item:{id:"minecraft:lingering_potion"}}

execute if entity @p[distance=..9] if predicate math:chance/10 run data merge entity @s {Item:{tag:{Potion:"minecraft:blindness",custom_potion_effects:[{id:"minecraft:blindness",duration:120}]}}}

tag @s add upgradedmobs.witches.potion
