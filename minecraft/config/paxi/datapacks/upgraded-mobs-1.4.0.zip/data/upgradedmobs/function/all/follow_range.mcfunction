attribute @s generic.follow_range modifier add upgradedmobs:all/follow_range 25 add_value

tag @s add upgradedmobs.all.sight
